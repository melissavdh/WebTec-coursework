function changeCursor() {
    document.body.style.cursor="help";
}

function defaultCursor() {
    document.body.style.cursor="default";
}
